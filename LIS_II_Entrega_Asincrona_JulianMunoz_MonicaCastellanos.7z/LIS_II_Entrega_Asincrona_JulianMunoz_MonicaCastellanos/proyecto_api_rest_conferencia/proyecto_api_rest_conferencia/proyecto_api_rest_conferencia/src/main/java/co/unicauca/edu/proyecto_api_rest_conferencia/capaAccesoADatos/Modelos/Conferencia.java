package co.unicauca.edu.proyecto_api_rest_conferencia.capaAccesoADatos.Modelos;
import java.util.ArrayList;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Conferencia {
    private int id;
    private String nombre;

    private int cantidadMaxArticulos;
    private ArrayList<Articulo> articuloList= new ArrayList<Articulo>();
    public Conferencia(){

    }
    
}
