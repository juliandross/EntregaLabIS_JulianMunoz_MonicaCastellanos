package co.unicauca.edu.proyecto_api_rest_conferencia.fachadaServicios.DTO;
import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ArticuloDTO  implements Serializable{
    Integer id;
    public ArticuloDTO(){
        
    }
    
}
