/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicios;

import java.util.List;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;

import modelos.ConferenciaDTO;
import org.glassfish.jersey.jackson.JacksonFeature;

/**
 *
 * @author julia
 */
public class ConferenciaServices {
    private String endPoint;
    private Client client;
    public ConferenciaServices(){
            this.endPoint="http://localhost:5001/api";
            client = ClientBuilder.newClient().register(new JacksonFeature());
    }
    	public boolean existeConferenciaDTO(Integer id)
	{
		WebTarget target = client.target(this.endPoint+"/conferencia/"+id);
		Boolean flag = target.request(MediaType.APPLICATION_JSON_TYPE).get(Boolean.class);
		return flag;
	}
        
        public List<ConferenciaDTO> listarConferenciaDTOs()
	{
		List<ConferenciaDTO> listaConferenciaDTOs=null;		
		WebTarget target = client.target(this.endPoint+"/conferencias");
		listaConferenciaDTOs = target.request(MediaType.APPLICATION_JSON).get(new GenericType<List<ConferenciaDTO>>() {});		
		return listaConferenciaDTOs;
	}
        
        
	public ConferenciaDTO registrarConferenciaDTO(ConferenciaDTO objConferenciaDTO)
	{
            ConferenciaDTO  objCon=null;
            WebTarget target = client.target(this.endPoint+"/conferencias");	    
	    Entity<ConferenciaDTO> data = Entity.entity(objConferenciaDTO, MediaType.APPLICATION_JSON_TYPE);
	    objCon = target.request(MediaType.APPLICATION_JSON_TYPE).post(data, ConferenciaDTO.class);		
		return objCon;
	}
        
        public ConferenciaDTO actualizarConferenciaDTO(int id,ConferenciaDTO objConferenciaDTO){
            ConferenciaDTO  objCon=null;
            WebTarget target = client.target(this.endPoint+"/conferencias/"+id);	    
	    Entity<ConferenciaDTO> data = Entity.entity(objConferenciaDTO, MediaType.APPLICATION_JSON_TYPE);
	    objCon = target.request(MediaType.APPLICATION_JSON_TYPE).put(data, ConferenciaDTO.class);		
            return objCon;
        }
        public ConferenciaDTO eliminarConferenciaDTO(int id){
            ConferenciaDTO  objCon=null;
            WebTarget target = client.target(this.endPoint+"/conferencias/"+id);	    
	    objCon = target.request(MediaType.APPLICATION_JSON_TYPE).delete(ConferenciaDTO.class);		
            return objCon;
        }
}
