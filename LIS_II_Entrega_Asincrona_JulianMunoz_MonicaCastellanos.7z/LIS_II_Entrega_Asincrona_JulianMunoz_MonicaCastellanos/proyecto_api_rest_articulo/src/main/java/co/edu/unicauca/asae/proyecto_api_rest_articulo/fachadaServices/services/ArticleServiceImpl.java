package co.edu.unicauca.asae.proyecto_api_rest_articulo.fachadaServices.services;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.stereotype.Service;

import co.edu.unicauca.asae.proyecto_api_rest_articulo.capaAccesoADatos.repositories.UsuarioRepository;
import co.edu.unicauca.asae.proyecto_api_rest_articulo.fachadaServices.DTO.ArticleDTO;
import co.edu.unicauca.asae.proyecto_api_rest_articulo.rabbit.MessageProducer;
import co.edu.unicauca.asae.proyecto_api_rest_articulo.capaAccesoADatos.models.ArticleEntity;
import lombok.AllArgsConstructor;

@Service


@AllArgsConstructor
public class ArticleServiceImpl implements IArticleService {
    private UsuarioRepository servicioAccesoBaseDatos;
	private final MessageProducer publicador;
	private ModelMapper modelMapper;

    @Override
	public List<ArticleDTO> findAll() {

		List<ArticleEntity> articulosEntity = this.servicioAccesoBaseDatos.findAll();
		List<ArticleDTO> articulosDTO = this.modelMapper.map(articulosEntity, new TypeToken<List<ArticleDTO>>() {
		}.getType());
		return articulosDTO;
	}

	@Override
	public ArticleDTO findById(Integer id) {
		ArticleEntity objArticleEntity = this.servicioAccesoBaseDatos.findById(id);
		if(objArticleEntity == null){
			return null;
		}
		ArticleDTO articleDTO = this.modelMapper.map(objArticleEntity, ArticleDTO.class);
		return articleDTO;
	}

	@Override
	public ArticleDTO save(ArticleDTO articulo) {
		ArticleEntity articuloEntity = this.modelMapper.map(articulo, ArticleEntity.class);
		ArticleEntity objArticleEntity = this.servicioAccesoBaseDatos.save(articuloEntity);
		ArticleDTO articuloDTO = this.modelMapper.map(objArticleEntity, ArticleDTO.class);
		//Envío a rabbitMQ
		publicador.sendMessage(articuloDTO);
		return articuloDTO;
	}

	@Override
	public ArticleDTO update(Integer id, ArticleDTO articulo) {
		ArticleEntity articleEntity = this.modelMapper.map(articulo, ArticleEntity.class);
		ArticleEntity articleEntityActualizado = this.servicioAccesoBaseDatos.update(id, articleEntity);
		ArticleDTO articleDTO = this.modelMapper.map(articleEntityActualizado, ArticleDTO.class);
		return articleDTO;
	}

	@Override
	public boolean delete(Integer id) {
		return this.servicioAccesoBaseDatos.delete(id);
	}
}
