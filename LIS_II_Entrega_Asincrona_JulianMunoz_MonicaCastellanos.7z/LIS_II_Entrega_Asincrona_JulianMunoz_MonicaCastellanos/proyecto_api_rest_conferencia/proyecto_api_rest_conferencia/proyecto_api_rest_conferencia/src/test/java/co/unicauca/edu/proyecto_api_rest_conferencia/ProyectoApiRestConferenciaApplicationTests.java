package co.unicauca.edu.proyecto_api_rest_conferencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoApiRestConferenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
