package co.unicauca.edu.proyecto_api_rest_conferencia.capaAccesoADatos.Repositorio;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Repository;

import co.unicauca.edu.proyecto_api_rest_conferencia.capaAccesoADatos.Modelos.Articulo;
import co.unicauca.edu.proyecto_api_rest_conferencia.capaAccesoADatos.Modelos.Conferencia;
import co.unicauca.edu.proyecto_api_rest_conferencia.fachadaServicios.DTO.ConferenciaDTO;

@Repository
public class RepositorioConferencia{
/**Yo como administrador quiero registrar una conferencia para que expositores puedan presentar sus artículos.
Yo como administrador quiero listar las conferencias registradas para que expositores puedan ver en cuales
conferencias presentar sus artículos.
Yo como administrador quiero consultar si existe una conferencia para establecer si se pueden registrar
artículos
Yo como administrador quiero consultar la cantidad de artículos registrados en una conferencia para ver si
alcanzo su tope. */ 
public ArrayList<Conferencia> listaDeConferencias;
public RepositorioConferencia()
{
this.listaDeConferencias=new ArrayList<Conferencia>();

cargarConferencia();
}

private void cargarConferencia()
{

    ArrayList<Articulo> listaArticulos1 = new ArrayList<Articulo>();
    Articulo art1= new Articulo(1);
    Articulo art2= new Articulo(2);
    Articulo art3= new Articulo(3);

    listaArticulos1.add(art1);
    listaArticulos1.add(art2);
    listaArticulos1.add(art3);

    Conferencia objConferencia1= new Conferencia(1, "Conferencia Harry Potter",20, listaArticulos1);
    listaDeConferencias.add(objConferencia1);

    ArrayList<Articulo> listaArticulos2 = new ArrayList<Articulo>();
    Articulo art4= new Articulo(4);
    Articulo art5= new Articulo(5);
    Articulo art6= new Articulo(6);

    listaArticulos2.add(art1);
    listaArticulos2.add(art5);
    listaArticulos2.add(art6);

    Conferencia objConferencia2= new Conferencia(2, "SCRUM ", 20, listaArticulos2);
    listaDeConferencias.add(objConferencia2);

    ArrayList<Articulo> listaArticulos3 = new ArrayList<Articulo>();
    Articulo art7= new Articulo(7);
    Articulo art8= new Articulo(8);
    Articulo art9= new Articulo(9);

    listaArticulos3.add(art1);
    listaArticulos3.add(art8);
    listaArticulos3.add(art9);
    Conferencia objConferencia3= new Conferencia(3, "Arquitectura Hexagonal", 20, listaArticulos3);
    listaDeConferencias.add(objConferencia3);
}
public Conferencia eliminarConferencia(int id){
    Conferencia conferencia;
    for(int i=0;i<this.listaDeConferencias.size();i++){
        if(id==listaDeConferencias.get(i).getId()){
            conferencia=listaDeConferencias.get(i);
            this.listaDeConferencias.remove(i);
            return conferencia;
        }
    }
    return null;
}
public List<Conferencia> getConferencias(){
    System.out.println("Listar Conferencias");
    return this.listaDeConferencias;
}

public Conferencia registrarConferencia(Conferencia prmConferencia){
    Conferencia conferencia = null;
    if(this.listaDeConferencias.add(prmConferencia)){
        conferencia = prmConferencia;
    }
    return conferencia;
}

public Conferencia setConferencia(int id,Conferencia prmConferencia){
    System.out.println("Editando conferencia");
    int idx=-1;
    for(int i=0;i<this.listaDeConferencias.size();i++){
        if(id==listaDeConferencias.get(i).getId()){
            idx=i;
        }
    }
    return this.listaDeConferencias.set(idx,prmConferencia);
}


public boolean  conferenciaExiste(int prmId){
    boolean bell=false;
    for(int i=0; i<this.listaDeConferencias.size();i++){
    if(this.listaDeConferencias.get(i).getId()==prmId){ 
        bell=true;
        break;

    }

}
return bell; 

}

/**En el repositorio de conferencias, cree un método que reciba el identificador de un artículo, recorra
las conferencias y retorne las conferencias donde se encuentra el artículo */
public List<Conferencia> ListarConferenciasSegunArticulo(int idArticulo) {
    System.out.println("Obteniendo las conferencias en las que se encuentra el artículo");
    ArrayList<Conferencia> listaConferencias= new ArrayList<Conferencia>();
    for (int i = 0; i < this.listaDeConferencias.size(); i++) {
        List<Articulo> listaArticulos=this.listaDeConferencias.get(i).getArticuloList();
        for (int j = 0; j < listaArticulos.size(); j++) {
            if(listaArticulos.get(j).getId()==idArticulo)
            {					
                listaConferencias.add(this.listaDeConferencias.get(i));
                break;
            }
        }
    }
    System.out.println("lista retornada "+listaConferencias.size());
    return listaConferencias;
}



//Falta asociar a Articulo
public int numArticulos(int prmId){
    Random random = new Random();
    return random.nextInt(0, 9);
}

}