package co.edu.unicauca.asae.proyecto_api_rest_articulo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoApiRestArticuloApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoApiRestArticuloApplication.class, args);
	}

}
