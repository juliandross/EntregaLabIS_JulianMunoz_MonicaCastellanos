package co.edu.unicauca.asae.proyecto_api_rest_articulo.capaAccesoADatos.repositories;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import co.edu.unicauca.asae.proyecto_api_rest_articulo.capaAccesoADatos.models.ArticleEntity;
@Repository
public class UsuarioRepository {
    private ArrayList<ArticleEntity> listaDeArticulos;

	public UsuarioRepository() {
		this.listaDeArticulos = new ArrayList<ArticleEntity>();
		cargarArticulos();
	}

	public List<ArticleEntity> findAll() {
		System.out.println("Invocando a listar todos articulos");
		return this.listaDeArticulos;
	}

	public ArticleEntity findById(Integer id) {
		System.out.println("Invocando a consultar un articulo por id");
		ArticleEntity objArticulo = null;
		
		for (ArticleEntity articulo : listaDeArticulos) {
			if (articulo.getId() == id) {
				objArticulo = articulo;
				break;
			}
		}

		return objArticulo;
	}

	public ArticleEntity save(ArticleEntity articulo) {
		System.out.println("Invocando a almacenar un articulo");
		ArticleEntity objArticulo = null;
		if (this.listaDeArticulos.add(articulo)) {
			objArticulo = articulo;
		}

		return objArticulo;
	}

	public ArticleEntity update(Integer id, ArticleEntity articulo) {
		System.out.println("Invocando a actualizar un articulo");
		ArticleEntity objArticulo = null;

		for (int i = 0; i < this.listaDeArticulos.size(); i++) {
			if (this.listaDeArticulos.get(i).getId() == id) {
				this.listaDeArticulos.set(i, articulo);
				objArticulo = articulo;
				break;
			}
		}

		return objArticulo;
	}

	public boolean delete(Integer id) {
		System.out.println("Invocando a eliminar un articulo");
		boolean bandera = false;

		for (int i = 0; i < this.listaDeArticulos.size(); i++) {
			if (this.listaDeArticulos.get(i).getId() == id) {
				this.listaDeArticulos.remove(i);
				bandera = true;
				break;
			}
		}

		return bandera;
	}

	private void cargarArticulos() {
		ArticleEntity objArticulo1 = new ArticleEntity(1, "Oceano caucano", "Oceanos", "Ricardo, Pablito", 2);
		this.listaDeArticulos.add(objArticulo1);
		ArticleEntity objArticulo2 = new ArticleEntity(2, "Barcelona", "Marca", "Ansu Fragil, Lamine Yamal", 2);
		this.listaDeArticulos.add(objArticulo2);
		ArticleEntity objArticulo3 = new ArticleEntity(3, "Paila", "Semana", "Vicky Dabala", 1);
		this.listaDeArticulos.add(objArticulo3);
		ArticleEntity objArticulo4 = new ArticleEntity(4, "Las maravillas de Argelia", "revista guerrillera", "Adrian", 1);
		this.listaDeArticulos.add(objArticulo4);
	}
}


