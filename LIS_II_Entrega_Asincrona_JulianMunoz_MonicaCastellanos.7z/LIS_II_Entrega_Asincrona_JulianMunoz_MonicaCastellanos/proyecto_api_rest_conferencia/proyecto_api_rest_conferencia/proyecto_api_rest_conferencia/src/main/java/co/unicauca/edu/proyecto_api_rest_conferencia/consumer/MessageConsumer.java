package co.unicauca.edu.proyecto_api_rest_conferencia.consumer;

import org.springframework.stereotype.Component;

import co.unicauca.edu.proyecto_api_rest_conferencia.fachadaServicios.DTO.ArticuloDTO;
import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;

@Slf4j
@Component
public class MessageConsumer {
	@RabbitListener(queues = { "correoArticulo" })
	public void receive(@Payload ArticuloDTO articulo) {
		log.info("Received message from conferencia articulo con id {}", articulo.getId());
		System.out.println("\n\n****Simulacion de correo****\nNuevo articulo añadido!!!!!\nDatos del articulo recibidos de la cola\n\n");
		makeSlow();
	}

	private void makeSlow() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

    