package co.unicauca.edu.proyecto_api_rest_conferencia.fachadaServicios.servicios;
import java.util.List;

import co.unicauca.edu.proyecto_api_rest_conferencia.fachadaServicios.DTO.ConferenciaDTO;
public interface IConferenciaServicio {
    public List<ConferenciaDTO> getConferencias();
    public ConferenciaDTO setConferencia(int id,ConferenciaDTO prmConferencia);
    public boolean existeConferencia(int prmId);
    public int numArticulos(int prmId);
    public List<ConferenciaDTO>getConferenciasArticulo(int idArticulo);
    public ConferenciaDTO registrarConferencia(ConferenciaDTO prmConferenciaDTO);
    public ConferenciaDTO eliminarConferencia(int id);
}
