package co.edu.unicauca.asae.proyecto_api_rest_articulo.fachadaServices.services;

import java.util.List;
import co.edu.unicauca.asae.proyecto_api_rest_articulo.fachadaServices.DTO.ArticleDTO;
/*el controlador se comunica con la interfaz y la interfaz se comunica con clientedto */
public interface IArticleService {
    public List<ArticleDTO> findAll();

	public ArticleDTO findById(Integer id);

	public ArticleDTO save(ArticleDTO cliente);

	public ArticleDTO update(Integer id, ArticleDTO cliente);

	public boolean delete(Integer id);
}

