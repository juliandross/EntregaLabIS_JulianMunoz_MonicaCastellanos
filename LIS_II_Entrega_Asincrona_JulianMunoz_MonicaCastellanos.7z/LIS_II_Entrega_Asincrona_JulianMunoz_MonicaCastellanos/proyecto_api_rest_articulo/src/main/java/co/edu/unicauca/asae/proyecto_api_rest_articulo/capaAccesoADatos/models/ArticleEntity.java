package co.edu.unicauca.asae.proyecto_api_rest_articulo.capaAccesoADatos.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter; 

@Getter //genera todos los gets para todos los atributos
@Setter //genera todos los sets para todos los atributos
@AllArgsConstructor //genera todos los constructores para todos los atributos combinados, menos el vacio
public class ArticleEntity {
    private Integer id;
    private String title;
    private String journal;
    private String authors;
    private int cantAuthors;

    public ArticleEntity(){
        
    }

}
