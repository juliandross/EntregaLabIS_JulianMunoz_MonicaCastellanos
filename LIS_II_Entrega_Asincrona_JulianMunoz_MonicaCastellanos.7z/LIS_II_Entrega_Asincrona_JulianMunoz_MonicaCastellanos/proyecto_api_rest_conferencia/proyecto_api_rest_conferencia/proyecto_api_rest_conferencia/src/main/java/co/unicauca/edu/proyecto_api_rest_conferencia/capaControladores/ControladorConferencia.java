package co.unicauca.edu.proyecto_api_rest_conferencia.capaControladores;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.unicauca.edu.proyecto_api_rest_conferencia.fachadaServicios.DTO.ConferenciaDTO;
import co.unicauca.edu.proyecto_api_rest_conferencia.fachadaServicios.servicios.IConferenciaServicio;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;

@RestController
@RequestMapping("/api")
public class ControladorConferencia {
    @Autowired
  private IConferenciaServicio servicioConferencia;
  @GetMapping("/conferencias")
  public List<ConferenciaDTO> listarConferencia(){
    return servicioConferencia.getConferencias();
  } 
  @PostMapping("/conferencias")
  public ConferenciaDTO registrarConferencia(@RequestBody ConferenciaDTO prmConferencia){
    ConferenciaDTO objConferencia = null;
		objConferencia = servicioConferencia.registrarConferencia(prmConferencia);
    System.out.println("Consumiendo servicios para registrar conferencia "+prmConferencia.getNombre());
		return objConferencia;
  }
  @GetMapping("/conferencia/{prmId}")
public boolean consultarConferencia(@PathVariable Integer prmId){
    return servicioConferencia.existeConferencia(prmId);
}
@GetMapping("/conferencia2/{prmId}")
public int consultarArticulosConferencia(@PathVariable Integer prmId){
    return servicioConferencia.numArticulos(prmId);
}
@GetMapping("/conferencias/articulo/{idArticulo}")
public List<ConferenciaDTO> listandoConferenciasArticulo(@PathVariable Integer idArticulo) {
    System.out.println("Consumiendo servicios para obtener Conferencias del Articulo "+idArticulo);
    return servicioConferencia.getConferenciasArticulo(idArticulo);
}
@PutMapping("/conferencias/{id}")
public ConferenciaDTO setConferenciaDTO(@PathVariable int id, @RequestBody ConferenciaDTO conferencia) {
  System.out.println("Consumiendo servicios para editar conferencia "+conferencia.getNombre());
  return servicioConferencia.setConferencia(id,conferencia);
}

@DeleteMapping("/conferencias/{id}")
public ConferenciaDTO eliminarConferenciaDTO(@PathVariable int id){
  System.out.println("Consumiendo servicios para eliminar conferencia con id:"+id);
  return this.servicioConferencia.eliminarConferencia(id);
}

}
