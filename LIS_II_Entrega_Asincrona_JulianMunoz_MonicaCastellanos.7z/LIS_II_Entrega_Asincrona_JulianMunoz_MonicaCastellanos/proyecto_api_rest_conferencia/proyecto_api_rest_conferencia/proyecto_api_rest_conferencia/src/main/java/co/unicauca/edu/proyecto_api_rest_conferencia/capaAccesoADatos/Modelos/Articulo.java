package co.unicauca.edu.proyecto_api_rest_conferencia.capaAccesoADatos.Modelos;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Articulo {
    private int id;

    public Articulo(){
        
    }
    
}
