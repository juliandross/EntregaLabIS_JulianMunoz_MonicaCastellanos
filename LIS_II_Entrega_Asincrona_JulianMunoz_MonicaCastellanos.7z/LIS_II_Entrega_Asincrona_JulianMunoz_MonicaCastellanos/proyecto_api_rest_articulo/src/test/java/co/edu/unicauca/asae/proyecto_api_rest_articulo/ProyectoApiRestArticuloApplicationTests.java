package co.edu.unicauca.asae.proyecto_api_rest_articulo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoApiRestArticuloApplicationTests {

	@Test
	void contextLoads() {
	}

}
