package co.unicauca.edu.proyecto_api_rest_conferencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoApiRestConferenciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoApiRestConferenciaApplication.class, args);
	}

}
