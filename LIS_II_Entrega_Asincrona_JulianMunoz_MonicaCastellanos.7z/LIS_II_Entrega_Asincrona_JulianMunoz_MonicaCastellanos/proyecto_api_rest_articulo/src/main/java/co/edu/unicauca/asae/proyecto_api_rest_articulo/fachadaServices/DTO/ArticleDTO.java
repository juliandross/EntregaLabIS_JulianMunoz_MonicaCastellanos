package co.edu.unicauca.asae.proyecto_api_rest_articulo.fachadaServices.DTO;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

//esta clase encapsula datos que viajan de articulo al servidor
@Getter
@Setter
@AllArgsConstructor
public class ArticleDTO  implements Serializable{
    private Integer id;
    private String title;
    private String journal;
    private String authors;
    private int cantAuthors;

    public ArticleDTO(){
    
    }
}

