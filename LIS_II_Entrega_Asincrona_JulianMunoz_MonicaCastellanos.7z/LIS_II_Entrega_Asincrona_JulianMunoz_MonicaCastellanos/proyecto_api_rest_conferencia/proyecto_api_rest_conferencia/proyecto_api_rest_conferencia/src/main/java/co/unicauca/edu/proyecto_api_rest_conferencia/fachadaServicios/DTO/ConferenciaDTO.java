package co.unicauca.edu.proyecto_api_rest_conferencia.fachadaServicios.DTO;
import java.util.ArrayList;

import co.unicauca.edu.proyecto_api_rest_conferencia.capaAccesoADatos.Modelos.Articulo;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ConferenciaDTO {
    int id;
    String nombre;
    int cantidadMaxArticulos;
      private ArrayList<Articulo> articuloList= new ArrayList<Articulo>();
    public ConferenciaDTO(){

    }
}
