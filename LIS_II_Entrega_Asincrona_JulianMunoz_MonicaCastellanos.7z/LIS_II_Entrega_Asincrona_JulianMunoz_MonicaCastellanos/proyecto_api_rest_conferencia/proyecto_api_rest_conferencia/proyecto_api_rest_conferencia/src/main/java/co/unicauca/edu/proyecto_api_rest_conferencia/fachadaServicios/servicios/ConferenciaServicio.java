package co.unicauca.edu.proyecto_api_rest_conferencia.fachadaServicios.servicios;

import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.modelmapper.TypeToken;

import co.unicauca.edu.proyecto_api_rest_conferencia.capaAccesoADatos.Modelos.Conferencia;
import co.unicauca.edu.proyecto_api_rest_conferencia.capaAccesoADatos.Repositorio.RepositorioConferencia;
import co.unicauca.edu.proyecto_api_rest_conferencia.fachadaServicios.DTO.ConferenciaDTO;
@Service
public class ConferenciaServicio implements IConferenciaServicio {
    @Autowired
private RepositorioConferencia servicioAccesoBaseDatos;
    @Autowired
private ModelMapper modelMapper;
    @Override
    public List<ConferenciaDTO> getConferencias() {
        List<Conferencia> ConferenciasEntity= this.servicioAccesoBaseDatos.getConferencias();
        List<ConferenciaDTO> ConferenciasDto=this.modelMapper.map(ConferenciasEntity, new TypeToken<List<ConferenciaDTO>>(){
        }.getType());
        return ConferenciasDto;
    }

    @Override
    public ConferenciaDTO setConferencia(int id,ConferenciaDTO prmConferencia) {
        Conferencia ConferenciaEntity= this.modelMapper.map(prmConferencia, Conferencia.class);
        Conferencia objConferenciasEntity=this.servicioAccesoBaseDatos.setConferencia(id,ConferenciaEntity);
        ConferenciaDTO ConferenciasDTO=this.modelMapper.map(objConferenciasEntity, ConferenciaDTO.class);
        return ConferenciasDTO;
    }

    @Override
    public boolean existeConferencia(int prmId) {
        return this.servicioAccesoBaseDatos.conferenciaExiste(prmId);
    }

    @Override
    public int numArticulos(int prmId) {
        return this.servicioAccesoBaseDatos.numArticulos(prmId);
    }

    @Override
    public List<ConferenciaDTO>getConferenciasArticulo(int idArticulo){
        List<Conferencia> ConferenciasEntity= this.servicioAccesoBaseDatos.ListarConferenciasSegunArticulo(idArticulo);
        List<ConferenciaDTO> ConferenciasDto=this.modelMapper.map(ConferenciasEntity, new TypeToken<List<ConferenciaDTO>>(){
        }.getType());
        return ConferenciasDto;

    }

    @Override
    public ConferenciaDTO registrarConferencia(ConferenciaDTO prmConferenciaDTO) {
        Conferencia conferenciaEntity =  this.modelMapper.map(prmConferenciaDTO, Conferencia.class);
        conferenciaEntity=this.servicioAccesoBaseDatos.registrarConferencia(conferenciaEntity);
        return this.modelMapper.map(conferenciaEntity,ConferenciaDTO.class);
    }

    @Override
    public ConferenciaDTO eliminarConferencia(int id) {
        ConferenciaDTO conferenciaDTO = this.modelMapper.map(this.servicioAccesoBaseDatos.eliminarConferencia(id),ConferenciaDTO.class);
        return conferenciaDTO;
    }
    
}
